<template>
      <div class="sidebar left">
                <div class="box base-info">
                    <ul>
                        <li class="desc-item" style="overflow:hidden;">
                            <img src="//s3.bytecdn.cn/neihan/resource/neihan_web/static/image/site-v2/joke_jokeessay_new_c0cceed.png" alt="" class="left logo">
                            <div class="desc-wrapper left">
                                <div class="h1">内涵段子 APP</div>
                                <div class="h2">iPhone和Android平台最受欢迎的休闲娱乐软件、内涵社区，网络热辣段子发源地！</div>
                            </div>
                        </li>
                        <li class="star-score-item">
                            <div class="star-score-wrapper left">
                                <div class="stars">
                                    <span class="star"></span>
                                    <span class="star"></span>
                                    <span class="star"></span>
                                    <span class="star"></span>
                                    <span class="star"></span>
                                </div>
                                <span class="score">32639份评分</span>
                            </div>
                            <div class="qrcode-wrapper right">
                                <img src="//s3a.bytecdn.cn/neihan/resource/neihan_web/static/image/site-v2/qrcode_joke_essay_a60675d.png" alt="" class="qrcode">
                            </div>
                        </li>
                        <li class="download-btn-item">
                            <ul>
                                <li class="btn ios-dl-btn left">
                                    <a href="javascript:void(0)" onclick="window.open('http://s.toutiao.com/app/Dqy8/');" target="_blank">iOS下载</a>
                                </li>
                                <li class="btn android-dl-btn left">
                                    <a href="javascript:void(0)" onclick="window.open('http://s.toutiao.com/UwwAd/');" target="_blank">Android下载</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="box qq-contact-info">
                    <div class="header">段友官方QQ群</div>
                    <ul>
                        <li>内涵段子原创用户群 - 496919542（火热）</li>
                        <li>内涵视频创作群 - 543587206（火热）</li>
                        <!--<li>图文原创作者群 - 174323235（火热推荐）</li>-->
                <!-- 		<li class="more">
                            <a href="http://neihanshequ.com/contact/" class="right">更多涵友QQ群...</a>
                        </li> -->
                    </ul>
                </div>
    </div>
</template>
<script>
export default {
  
}
</script>
<style>


</style>


